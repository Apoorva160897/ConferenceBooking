import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { RxjsIntroComponent } from './RXJSintro.component';
import { receiverComponent } from './component2Component.comm/receiver.component';
import { senderComponent } from './component2Component.comm/sender.component';
import {FormsModule} from '@angular/forms';

import { adminComponent } from './component2Component.comm/movieTicketBooking/admin.component';
import { userComponent } from './component2Component.comm/movieTicketBooking/user.component';
import { ReadJSONComponent } from './component2Component.comm/read-json/read-json.component';
import { HttpClientModule } from '@angular/common/http';
import { ReadJSONasyncComponent } from './component2Component.comm/read-jsonasync/read-jsonasync.component';
import { ExternalServiceComponent } from './component2Component.comm/external-service/external-service.component';

@NgModule({
  declarations: [
    AppComponent, RxjsIntroComponent,receiverComponent,
    senderComponent,adminComponent,userComponent, ReadJSONComponent, 
    ReadJSONasyncComponent, ExternalServiceComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
