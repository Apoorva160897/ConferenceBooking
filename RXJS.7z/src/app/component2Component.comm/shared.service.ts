import {Injectable} from '@angular/core';
import {Subject} from 'rxjs';

@Injectable
({
    providedIn:'root'
})

export class shareDataService
{
    shareDataSubject=new Subject<any>();//declaring new RXJS subject

    sendDataToOtherComponent(somedata)
    {
        this.shareDataSubject.next(somedata);//next()--give the next value in queue
    }

}