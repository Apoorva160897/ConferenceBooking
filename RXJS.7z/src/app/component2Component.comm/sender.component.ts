import { Component, OnInit } from '@angular/core';
import {shareDataService} from './shared.service';

@Component({
    selector: 'sender-cmp',
    template: `
    <hr>
    <div>this is the sender component</div>
    <input type='button' value='sendData'
    (click)='passData()'>

    `
})

export class senderComponent implements OnInit {

    constructor(private ds:shareDataService) 
    {

    }
    passData()
    {
        this.ds.sendDataToOtherComponent(Math.random().toString());
    }

    ngOnInit() { }
}