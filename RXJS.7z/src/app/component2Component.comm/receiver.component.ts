import { Component, OnInit } from '@angular/core';
import {shareDataService} from './shared.service';


@Component({
    selector: 'receiver-cmp',
    template: `
    <hr>
    <div> This is the receiver component</div>
    <input type="text" [(ngModel)]="result">
    `
})

export class receiverComponent implements OnInit {
    result:string;

    constructor(private ds:shareDataService) 
    { 
        this.ds.shareDataSubject.subscribe(receivedData=>
            {
                console.log(receivedData);
                this.result=receivedData;
            });

    }

    ngOnInit() { }
}