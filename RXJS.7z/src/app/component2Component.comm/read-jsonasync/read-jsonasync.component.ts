import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-read-jsonasync',
  templateUrl: './read-jsonasync.component.html',
  styleUrls: ['./read-jsonasync.component.css']
})
export class ReadJSONasyncComponent implements OnInit {

  result:any;

  constructor(private http:HttpClient) 
  { 
    this.result=this.http.get('assets/friends.json');

  }

  ngOnInit() {
  }

}
