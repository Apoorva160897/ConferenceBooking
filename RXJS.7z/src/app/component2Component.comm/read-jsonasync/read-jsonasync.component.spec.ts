import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadJSONasyncComponent } from './read-jsonasync.component';

describe('ReadJSONasyncComponent', () => {
  let component: ReadJSONasyncComponent;
  let fixture: ComponentFixture<ReadJSONasyncComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReadJSONasyncComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadJSONasyncComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
