import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-external-service',
  templateUrl: './external-service.component.html',
  styleUrls: ['./external-service.component.css']
})
export class ExternalServiceComponent implements OnInit {
  
  results:any;

  constructor(private http:HttpClient) 
  {

  }

  ngOnInit() 
  {
    // this.http.get('https://jsonplaceholder.typicode.com/todos/1')
    // .subscribe(data => this.results=data);
       this.http.get('https://services.odata.org/V3/OData/OData.svc/Products?$format=json')
       .subscribe(data => this.results=data);
  }

}
