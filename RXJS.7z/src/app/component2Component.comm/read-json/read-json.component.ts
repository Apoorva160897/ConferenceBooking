import { Component, OnInit,OnDestroy } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-read-json',
  templateUrl: './read-json.component.html',
  styleUrls: ['./read-json.component.css']
})
export class ReadJSONComponent implements OnInit ,OnDestroy{
  result:any;
  subscription:Subscription;

  constructor(private http:HttpClient) { }

  ngOnInit() 
  {
    this.subscription=this.http.get('assets/friends.json')
    .subscribe((data)=>
    {
      this.result=data;
    });
  }

  ngOnDestroy()
  {
    this.subscription.unsubscribe();
  }

}
