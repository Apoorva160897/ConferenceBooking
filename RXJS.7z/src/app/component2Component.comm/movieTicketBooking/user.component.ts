import { Component, OnInit } from '@angular/core';
import {BookingService} from './booking.service';

@Component({
    selector: 'user-cmp',
    template: `
    <h4>user component</h4>
    <p>currently,no of tickets available={{currentTicketCount}}</p>
    <button (click)='bookTicket() '> Book ticket </button>
    `
})

export class userComponent implements OnInit {
    currentTicketCount:number;

    constructor(private bs:BookingService) 
    {
        this.bs.totalTicketCount.subscribe(totalTicketCount=>{
            this.currentTicketCount=totalTicketCount;

        });

    }

    bookTicket=()=>
    {
        this.currentTicketCount=this.currentTicketCount-1;
        this.bs.totalTicketCount.next(this.currentTicketCount);
    }

    ngOnInit() { }
}