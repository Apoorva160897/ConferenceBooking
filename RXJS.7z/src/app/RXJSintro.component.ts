import { Component, OnInit } from '@angular/core';
import {observable,interval,Subscription} from 'rxjs';
import {take} from 'rxjs/operators';

@Component({
    selector: 'rxjs-intro-cmp',
    template: `
    <h4>look at console window</h4>`
})

export class RxjsIntroComponent implements OnInit {

    mySubscription:Subscription;
    constructor() { }

    ngOnInit() 
    {
       const myNums=interval(2000);
    //    myNums.subscribe((result:number)=>{
    //        console.log(result);
    //    });
       const takeSixNumbers=myNums.pipe(take(6));

       this.mySubscription=takeSixNumbers.subscribe((x:number)=>{
           console.log(x);
       },undefined,()=>{console.log("subscription completed..")});
    }
}