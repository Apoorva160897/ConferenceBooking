import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'first-cmp',
    template: ``
})

export class FirstComponent implements OnInit {

    title:string='app works!';

    constructor() { }

    ngOnInit() { }
}