import {FirstComponent} from './first.component';

describe('FirstComponent',()=>{
    let firstComponent=new FirstComponent();

    it('should create the app',()=>{
        const app=firstComponent;
        expect(app).toBeTruthy();
    });

    it('should have `app works!` title',()=>{
        const title=firstComponent.title;
        expect(title).toEqual('app works!');
    });
});