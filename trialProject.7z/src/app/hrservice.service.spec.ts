import { TestBed } from '@angular/core/testing';

import { HRServiceService } from './hrservice.service';

describe('HRServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HRServiceService = TestBed.get(HRServiceService);
    expect(service).toBeTruthy();
  });
});
