import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeCMPComponent } from './employee-cmp.component';

describe('EmployeeCMPComponent', () => {
  let component: EmployeeCMPComponent;
  let fixture: ComponentFixture<EmployeeCMPComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeCMPComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeCMPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
