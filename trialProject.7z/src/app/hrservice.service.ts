import { Injectable } from '@angular/core';
import {HttpClient} from'@angular/common/http';
import {Emp} from './Model/Emp';

@Injectable({
  providedIn: 'root'
})
export class HRServiceService 
{
emps
edata:Emp;
emplist:string;
  constructor(public http:HttpClient)
   { 
     //this.emps=[]

   }

   addEmps(empdata:Emp)
   {
     console.log(empdata.Empid);
     console.log(empdata.Empname);
     console.log(empdata.Salary);
     console.log(empdata.Deptno);
     this.edata=new Emp();
     this.edata.Empid=empdata.Empid;
     this.edata.Empname=empdata.Empname;
     this.edata.Salary=empdata.Salary;
     this.edata.Deptno=empdata.Deptno;


      this.http.post('http://localhost:62327/api/Employee',this.edata)
      .subscribe(res => {
        this.emps=res
      })
      console.log("going to server");
   }

   delEmps(empdata:Emp)
   {
    console.log(empdata.Empid);
    this.edata=new Emp();
    this.edata.Empid=empdata.Empid;
    
    this.http.delete('http://localhost:62327/api/Employee/'+this.edata.Empid)
    .subscribe(res => {
      this.emps=res
    })
    console.log("going to server");
   }

   updateEmps(empdata:Emp)
   {
    console.log(empdata.Empid);
    console.log(empdata.Empname);
    console.log(empdata.Salary);
    console.log(empdata.Deptno);
    this.edata=new Emp();
    this.edata.Empid=empdata.Empid;
    this.edata.Empname=empdata.Empname;
    this.edata.Salary=empdata.Salary;
    this.edata.Deptno=empdata.Deptno;


     this.http.put('http://localhost:62327/api/Employee/'+this.edata.Empid,this.edata)
     .subscribe(res => {
       this.emps=res
     })
     console.log("going to server");
   }

   getEmps()
   {
    return this.http.get("http://localhost:62327/api/Employee");
 
   }

   GetEmpsById(Id:number)
   {
     return this.http.get("http://localhost:62327/api/Employee/"+Id);
   }
}
