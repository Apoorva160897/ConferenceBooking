import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeUpdComponent } from './employee-upd.component';

describe('EmployeeUpdComponent', () => {
  let component: EmployeeUpdComponent;
  let fixture: ComponentFixture<EmployeeUpdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeUpdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeUpdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
