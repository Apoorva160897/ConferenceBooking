import { Component, OnInit } from '@angular/core';
import { Emp } from '../Model/Emp';
import { HRServiceService } from '../hrservice.service';

@Component({
  selector: 'app-employee-upd',
  templateUrl: './employee-upd.component.html',
  styleUrls: ['./employee-upd.component.css']
})
export class EmployeeUpdComponent implements OnInit {

  emp:Emp;

  constructor(public hrservice:HRServiceService) 
  { }

  ngOnInit() {
    this.emp=new Emp();
  }
  public onFormSubmit(value:Emp)
  {

    this.hrservice.updateEmps(value);
  }

}
