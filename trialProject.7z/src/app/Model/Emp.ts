export class Emp
{
    Empid:number;
    Empname:string;
    Salary:number;
    Deptno:number;
}
