import { Component, OnInit } from '@angular/core';
import { Emp } from '../Model/Emp';
import { HRServiceService } from '../hrservice.service';


@Component({
  selector: 'app-emp-getbyid',
  templateUrl: './emp-getbyid.component.html',
  styleUrls: ['./emp-getbyid.component.css']
})
export class EmpGetbyidComponent implements OnInit {

  emp:Emp;
  edatalist:any;

  constructor(public hrservice:HRServiceService) 
  { }

  ngOnInit() {
    
    this.emp=new Emp();
  }
onClick(ID:number)
{
  console.log(ID);
  this.edatalist=this.hrservice.GetEmpsById(ID).subscribe(
    data=>{
      this.edatalist=data;
    });
  
}

}
