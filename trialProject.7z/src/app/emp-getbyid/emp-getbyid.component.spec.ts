import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpGetbyidComponent } from './emp-getbyid.component';

describe('EmpGetbyidComponent', () => {
  let component: EmpGetbyidComponent;
  let fixture: ComponentFixture<EmpGetbyidComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpGetbyidComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpGetbyidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
