import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeDelComponent } from './employee-del.component';

describe('EmployeeDelComponent', () => {
  let component: EmployeeDelComponent;
  let fixture: ComponentFixture<EmployeeDelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeDelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeDelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
