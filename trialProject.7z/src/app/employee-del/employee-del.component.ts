import { Component, OnInit } from '@angular/core';
import { Emp } from '../Model/Emp';
import { HRServiceService } from '../hrservice.service';

@Component({
  selector: 'app-employeeDel-cmp',
  templateUrl: './employee-del.component.html',
  styleUrls: ['./employee-del.component.css']
})
export class EmployeeDelComponent implements OnInit {
emp:Emp;

  constructor(public hrservice:HRServiceService) 
  { }

  ngOnInit() {
    this.emp=new Emp();
  }
  public onFormSubmit(value:Emp)
  {

    this.hrservice.delEmps(value);
  }

}