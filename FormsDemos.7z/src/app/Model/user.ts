export class user
{
    firstName:string;
    lastname:string;
    email:string;
    password:string;
}