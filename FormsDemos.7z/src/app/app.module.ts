import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SignupComponent } from './TemplateFormsDemos/signup/signup.component';
import {FormsModule,ReactiveFormsModule, EmailValidator} from '@angular/forms';
import { ReactiveSignupComponent } from './reactive-signup/reactive-signup.component';
import { LoginPageComponent } from './ReactiveFormsDemos/login-page/login-page.component';
import { ComplexValidationComponent } from './complex-validation/complex-validation.component';
import { ErrorsComponent } from './complex-validation/errors.component';
import { AgeValidatorDirective } from './complex-validation/AgeValidator.directive';
import { MyEmailValidatorDirective } from './complex-validation/EmailValidator.directive';

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    ReactiveSignupComponent,
    LoginPageComponent,
    ComplexValidationComponent,
    ErrorsComponent,AgeValidatorDirective,MyEmailValidatorDirective
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
