import { Component, OnInit } from '@angular/core';
import {user} from '../../Model/user';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user:user;

  constructor() { }

  ngOnInit()
  {
    this.user=new user();
  }

  public onFormSubmit({value,valid}:{value:user,valid:boolean})
  {
    this.user=value;
    console.log(this.user);
    console.log("valid: "+ valid);
  }

}
