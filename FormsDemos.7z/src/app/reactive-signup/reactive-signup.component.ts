import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import {user} from '../Model/user';

@Component({
  selector: 'app-reactive-signup',
  templateUrl: './reactive-signup.component.html',
  styleUrls: ['./reactive-signup.component.css']
})

export class ReactiveSignupComponent implements OnInit {

  signupForm:FormGroup;
  user:user;

 
  constructor()
{
    this.signupForm = new FormGroup({
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+')]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    });
  }


get f()
 { //1 method for accessing all controls
  return this.signupForm.controls;
}

get lastName() { //1 method for accessing lastname control only
  return this.signupForm.get("lastName");
}

save() {
  console.log(this.signupForm);

  if (this.signupForm.valid) {
    console.log('firstName is ', this.signupForm.get('firstName').value);
    console.log('Saved: ' + JSON.stringify(this.signupForm.value));
  }
}



  ngOnInit() {
  }

}

