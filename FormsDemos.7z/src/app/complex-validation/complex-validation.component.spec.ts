import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplexValidationComponent } from './complex-validation.component';

describe('ComplexValidationComponent', () => {
  let component: ComplexValidationComponent;
  let fixture: ComponentFixture<ComplexValidationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplexValidationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplexValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
