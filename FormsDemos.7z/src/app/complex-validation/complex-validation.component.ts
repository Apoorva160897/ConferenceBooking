import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators, NgForm} from '@angular/forms';

@Component({
  selector: 'app-complex-validation',
  templateUrl: './complex-validation.component.html',
  styleUrls: ['./complex-validation.component.css']
})
export class ComplexValidationComponent implements OnInit {

  validateForm:FormGroup;
  
  constructor() 
  { 
    this.validateForm=new FormGroup({
      'name':new FormControl(),
      'email':new FormControl(),
      'age':new FormControl(),
      'address':new FormGroup({
        'country':new FormControl(),
        'city':new FormControl()
      })

    });
  }

  register(validateForm:NgForm)
  {
    console.log("Registration successful..");
    console.log(validateForm.value);
    alert("hi  "+validateForm.value.name+"your information is saved");
  }

  ngOnInit() {
  }

}
