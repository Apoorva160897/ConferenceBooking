import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';

//import {user} from '../../Model/user';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit 
{
  signupForm:FormGroup;


  constructor()
   { 
    this.signupForm= new FormGroup({
  
      email: new FormControl('', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+')]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    });
   }

   save() 
   {
    console.log(this.signupForm);
  
    if (this.signupForm.valid) {
     // console.log('firstName is ', this.signupForm.get('firstName').value);
      console.log('Saved: ' + JSON.stringify(this.signupForm.value));
    }
  }

  reset()
  {
    console.log(this.signupForm);
   
   

  }

  ngOnInit() {
  }

}
