import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertFacilitiesComponent } from './insert-facilities.component';

describe('InsertFacilitiesComponent', () => {
  let component: InsertFacilitiesComponent;
  let fixture: ComponentFixture<InsertFacilitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsertFacilitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsertFacilitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
