import { Component, OnInit } from '@angular/core';
import {FacilitiesService} from '../facilities.service';
import { Facility } from '../Model/facility';


@Component({
  selector: 'app-insert-facilities',
  templateUrl: './insert-facilities.component.html',
  styleUrls: ['./insert-facilities.component.css']
})
export class InsertFacilitiesComponent implements OnInit {
  facility:Facility;

  constructor(public facilities:FacilitiesService) { }

  insert_faci(facility){

  
    this.facilities.addFaci(facility);
  }
  

  ngOnInit() {
  }

}
