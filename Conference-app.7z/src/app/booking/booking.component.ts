import { Component, OnInit,Output,EventEmitter,AfterViewInit } from '@angular/core';

import{RoomType} from './RoomType'

import {Rooms} from './../Model/Rooms'
import {HttpClient} from '@angular/common/http'
import { Time } from '@angular/common';
import{Booking} from './../Model/Booking'
import{FormControl,FormGroup, Validators} from '@angular/forms';
@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit,AfterViewInit {
  @Output() messageEvent = new EventEmitter<string>();
locationsss:string;
Roomdetails:Rooms;
emps;
pStartdate:Date;
pEndDate:Date;
pStarttime:Time;
pendtime:Time;
BookingDetails:Booking=new Booking();
  selectedLocation:string;
  selectedRoomID:number;
  
edatalist:string[];
Rdata:Rooms;
  BookingForm:FormGroup;   
  constructor(private g:HttpClient)
  {

    this.BookingForm = new FormGroup({
      EmployeeID: new FormControl('',[Validators.required,Validators.minLength(7)]),
      roomtypeselect: new FormControl('', Validators.required),
      StartDate:new FormControl('', Validators.required),
      EndDate:new  FormControl('', Validators.required),
      StartTime:new  FormControl('', Validators.required),
      EndTime:new  FormControl('', Validators.required)
    
    });

  }

// 

//   onSelect(Locationid) { 
    
//     for (var i = 0; i < this.Locations.length; i++)
//     {
//       if (this.Locations[i].id == Locationid) {
//         this.selectedLocation.id = this.Locations[i].id;
//          this.selectedLocation.name = this.Locations[i].name;
      
//         }
//     }
// }

 locationss()
{

this.messageEvent.emit(this.locationsss);

}
  ngOnInit() {
//     this.Rdata= new RDMODEL();
//   this.Rdata.RoomLocation=this.selectedLocation.name;
//   this.Rdata.RoomType=this.selectedRoom.name;

// this.g.get('http://localhost:62350/api/BookingConference/getdetails'+this.Rdata).subscribe(  
//   data => {  
//    this.edatalist = data as string [];  
//   }  
// );  

  }

  roomtype:string;
  selectedRoom:RoomType = new RoomType(1, 'Conference');
  Roomtypes=[ new RoomType(1, 'Conference' ),
  
  new RoomType(2, 'Training' ),
  new RoomType(3, 'Discussion')
  
];
     
  

  onRSelect(roomid) { 
    
    for (var i = 0; i < this.Roomtypes.length; i++)
    {
      if (this.Roomtypes[i].id == roomid) {
        this.selectedRoom.id = this.Roomtypes[i].id;
         this.selectedRoom.name = this.Roomtypes[i].name;
      
        }
    }
}
getidlocation(roomid:number)
{

this.BookingDetails.RoomId=roomid;


}
getotherDetails(empid:number,std:Date,etd:Date,st:Time,et:Time)
{
  
  
this.BookingDetails.ProgramStartDate=std;
this.BookingDetails.EmpId=empid;
this.BookingDetails.ProgramEndDate=etd;
this.BookingDetails.BookingEndTime=et;
this.BookingDetails.BookingStartTime=st;
 console.log(this.pStarttime);
  
  console.log(this.BookingDetails.BookingDate);
  console.log(this.BookingDetails.BookingStartTime);
  console.log(this.BookingDetails.ProgramEndDate);
  console.log(this.BookingDetails.BookingEndTime);
  console.log(this.BookingDetails.ProgramStartDate);
  console.log(this.BookingDetails.RoomId);

this.g.post('http://localhost:49567/api/Booking',this.BookingDetails).subscribe(res =>this.emps= res );
alert("Booking successful!");
}

getroomdetails()
{
  this.Rdata= new Rooms();
 // this.Rdata.RoomLocationID=this.selectedLocation.id;
 // this.Rdata.RoomLocation=this.selectedLocation.name;
  this.Rdata.RoomType=this.selectedRoom.name;
 console.log(this.Rdata.Location);
 console.log(this.Rdata.RoomType);

  this.g.get('http://localhost:49567/api/Rooms?id='+ this.selectedRoom.name).subscribe(  
    data => {  
     this.edatalist = data as string [];  
    }  
  );  
  console.log(this.edatalist);
  
// console.log(this.fd.GetroomDetails(this.Rdata));
//   this.edatalist=this.fd.GetroomDetails(this.Rdata);

}

ngAfterViewInit()
{
  

}

}

