import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-stat',
  templateUrl: './book-stat.component.html',
  styleUrls: ['./book-stat.component.css']
})
export class BookStatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
