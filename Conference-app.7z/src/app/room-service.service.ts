import { Injectable } from '@angular/core';
import { Rooms } from './Model/Rooms';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class RoomServiceService {
  rooms
  rdata: Rooms;


  constructor(public http: HttpClient) { }

  addrooms(roomdata: Rooms) {
    console.log(roomdata.RoomId);
    console.log(roomdata.FacilityType);
    console.log(roomdata.LocCoordinatorId);
    console.log(roomdata.RoomName);
    console.log(roomdata.RoomType);
    console.log(roomdata.Capacity);
    console.log(roomdata.Location);
    this.rdata = new Rooms();
    this.rdata.RoomId = roomdata.RoomId;
    this.rdata.FacilityType = roomdata.FacilityType;
    this.rdata.LocCoordinatorId = roomdata.LocCoordinatorId;
    this.rdata.RoomName = roomdata.RoomName;
    this.rdata.RoomType = roomdata.RoomType;
    this.rdata.Capacity = roomdata.Capacity;
    this.rdata.Location = roomdata.Location;
    console.log(this.rdata);
    this.http.post('http://localhost:49567/api/Rooms', this.rdata).subscribe(res => this.rooms = res);
    console.log('going to server');
  }

  updateroom(roomdata: Rooms) {
    this.rdata = new Rooms();
    this.rdata.RoomId = roomdata.RoomId;
    this.rdata.FacilityType = roomdata.FacilityType;
    this.rdata.LocCoordinatorId = roomdata.LocCoordinatorId;

    this.rdata.RoomName = roomdata.RoomName;
    this.rdata.RoomType = roomdata.RoomType;
    this.rdata.Capacity = roomdata.Capacity;
    this.rdata.Location = roomdata.Location;

    console.log('updateting in service');
    this.http.put("http://localhost:49567/api/Rooms/"+ this.rdata.RoomId, this.rdata)
      .subscribe(result => this.rooms = result);

  }

  showrooms() {
    return this.http.get('http://localhost:49567/api/Rooms');
  }


}
