import { Injectable } from '@angular/core';
import {Facility} from './Model/Facility';
import {HttpClient} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})

  export class FacilitiesService {
    Faci:string[];
    facidata:Facility;
  
    constructor(public http:HttpClient) { }
  
    addFaci(edata:Facility)
  {
  this.facidata=new Facility();
  this.facidata.FacilityType=edata.FacilityType;
  this.facidata.TableType=edata.TableType;
  this.facidata.NoOfMachines=edata.NoOfMachines;
  
  this.facidata.WhiteBoard=edata.WhiteBoard;
  this.facidata.Network=edata.Network;
  this.facidata.FlipChart=edata.FlipChart;
  this.facidata.InternetConnectivity=edata.InternetConnectivity;
  this.facidata.Projector=edata.Projector;
  this.facidata.Screen=edata.Screen;
  this.facidata.Video=edata.Video;
  this.facidata.Phone=edata.Phone;
    this.http.post("http://localhost:49567/api/Facilities",this.facidata)
    .subscribe( result =>this.Faci=result as string[]);
  }
  
  updateFaci(edata:Facility)
  {this.facidata=new Facility();
    this.facidata.FacilityType=edata.FacilityType;
    this.facidata.TableType=edata.TableType;
    this.facidata.NoOfMachines=edata.NoOfMachines;
    
    this.facidata.WhiteBoard=edata.WhiteBoard;
    this.facidata.Network=edata.Network;
    this.facidata.FlipChart=edata.FlipChart;
    this.facidata.InternetConnectivity=edata.InternetConnectivity;
    this.facidata.Projector=edata.Projector;
    this.facidata.Screen=edata.Screen;
    this.facidata.Video=edata.Video;
    this.facidata.Phone=edata.Phone;
      this.http.put("http://localhost:49567/api/Facilities/"+this.facidata.FacilityType,this.facidata)
      .subscribe( result =>this.Faci=result as string[]);
  
  }
  
  showfacilities()
  {
   return this.http.get('http://localhost:49567/api/Facilities');
  }
  


}
