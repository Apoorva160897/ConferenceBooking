import { Component, OnInit } from '@angular/core';
import {FacilitiesService} from '../facilities.service';
import { Facility } from '../Model/facility';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-show-facilities',
  templateUrl: './show-facilities.component.html',
  styleUrls: ['./show-facilities.component.css']
})
export class ShowFacilitiesComponent implements OnInit {

  facility:Facility;
  ft:string[];
  Faci:string[];
   constructor(public facilities:FacilitiesService,public ps:HttpClient) { }
 
   
   get_faci(){
 
   this.facilities.showfacilities();
     
   }
 

  ngOnInit() {
    this.ps.get('http://localhost:49567/api/Facilities').subscribe(
      (data)=>{this.ft=data as string[]}
      )
  }

}
