import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import {Emp} from '../Model/Emp';
import {LoginServiceService} from '../login-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginform:FormGroup;
  employee:Emp;
  edatalist:any;
  myBooleanVal : Boolean;
  constructor(public loginService:LoginServiceService,private router:Router) 
  { 
    this.loginform=new FormGroup({
      EmpId:new FormControl('',[Validators.required,Validators.maxLength(7)]),
      password:new FormControl('',[Validators.required,Validators.minLength(8),Validators.maxLength(16)])

    });

  }
  
  

  // getBooleanValue(){
  //   this.loginService.getBoolean().subscribe(x=>{
  //     this.myBooleanVal = x;
  //     console.log(x,"X Value");// this print true "X Value"
  //     console.log(this.myBooleanVal);// this prints "true"
  //   });
  // }
  ngOnInit() {
    this.employee=new Emp();
  }
  
  get f()
  {
    return this.loginform.controls;
  }

  // redirectMe()
  // {
  //   this.router.navigate(['./employee-cmp']);
  // }

public onClick(id:number,pwd:string)
{
  // console.log(id);
  // console.log(pwd);
  
 // this.edatalist=this.loginService.checkUser(id,pwd);
 this.myBooleanVal=false;
  this.myBooleanVal=this.loginService.checkUser(id,pwd);
  // console.log(this.myBooleanVal);
  // if(this.myBooleanVal==true)
  // {
  //   //this.router.navigateByUrl("/employee-cmp");
  //   this.redirectMe();
  // }
  //return this.myBooleanVal;
}
  public onFormSubmit(id:number)
  {
    console.log(id);

    this.edatalist=this.loginService.getEmpType(id).subscribe(
      data=>{
        this.edatalist=data;
      });
      
  }

  save() {
    console.log(this.loginform);
  
    if (this.loginform.valid) {
      console.log('empid is ', this.loginform.get('empid').value);
      console.log('Saved: ' + JSON.stringify(this.loginform.value));
    }
 
  }
}


