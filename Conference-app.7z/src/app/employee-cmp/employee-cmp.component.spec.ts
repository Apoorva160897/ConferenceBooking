import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeCmpComponent } from './employee-cmp.component';

describe('EmployeeCmpComponent', () => {
  let component: EmployeeCmpComponent;
  let fixture: ComponentFixture<EmployeeCmpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeCmpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeCmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
