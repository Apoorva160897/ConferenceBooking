import { Component, OnInit } from '@angular/core';
import {Emp} from '../Model/Emp';
import {EmpServiceService} from '../emp-service.service';

@Component({
  selector: 'app-employee-cmp',
  templateUrl: './employee-cmp.component.html',
  styleUrls: ['./employee-cmp.component.css']
})
export class EmployeeCmpComponent implements OnInit {
  emp:Emp

  constructor(public empservice:EmpServiceService) { }

  ngOnInit()
  {
    this.emp=new Emp();
  }

  public onFormSubmit1(value:Emp)
  {

    this.empservice.addEmps(value);
  }

  public onFormSubmit2(value:Emp)
  {
    this.empservice.updateEmps(value);
  }
}
