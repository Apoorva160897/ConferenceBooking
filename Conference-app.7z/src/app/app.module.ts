import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { EmployeeCmpComponent } from './employee-cmp/employee-cmp.component';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';

import {HttpClientModule} from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { BookingComponent } from './booking/booking.component';
 import { InsertroomComponent } from './insertroom/insertroom.component';
 import { UpdateroomComponent } from './updateroom/updateroom.component';
import { BookStatComponent } from './book-stat/book-stat.component';

import { InsertFacilitiesComponent } from './insert-facilities/insert-facilities.component';
import { UpdateFacilitiesComponent } from './update-facilities/update-facilities.component';
import { ShowFacilitiesComponent } from './show-facilities/show-facilities.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    EmployeeCmpComponent,
    HomeComponent,
    BookingComponent,
    InsertroomComponent,
   UpdateroomComponent,
    BookStatComponent,
 
    InsertFacilitiesComponent,
 
    UpdateFacilitiesComponent,
 
    ShowFacilitiesComponent
  
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,  FormsModule,
    HttpClientModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
