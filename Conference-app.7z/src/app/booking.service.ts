import { Injectable } from '@angular/core';
import {HttpClient} from'@angular/common/http';
import {Booking} from './Model/Booking';
import { Rooms } from './Model/Rooms';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  bdata:Booking;
  rdata:Rooms;
  book

  constructor(public http:HttpClient) { }



  addBooking(bookdata:Booking)
  {
   
    console.log(bookdata.EmpId);
    console.log(bookdata.RoomId);
    console.log(bookdata.BookingDate);
    console.log(bookdata.BookingStartTime);
    console.log(bookdata.BookingEndTime);
    console.log(bookdata.ProgramStartDate);
    console.log(bookdata.ProgramEndDate);
    console.log(bookdata.BookingStatus);
    this.bdata=new Booking();
    this.bdata.EmpId=bookdata.EmpId;
    this.bdata.RoomId=bookdata.RoomId;
    this.bdata.BookingDate=bookdata.BookingDate;
    this.bdata.BookingStartTime=bookdata.BookingStartTime;
    this.bdata.BookingEndTime=bookdata.BookingEndTime;
    this.bdata.ProgramStartDate=bookdata.ProgramStartDate;
    this.bdata.ProgramEndDate=bookdata.ProgramEndDate;
    this.bdata.BookingStatus=bookdata.BookingStatus;
    this.http.post('http://localhost:49567/api/Booking/',this.bdata)
    .subscribe(res => {
      this.book=res
    })
    console.log("going to server");
  }



  getRoomDetails()
  {
   this.rdata=new Rooms;
  }
  
}
