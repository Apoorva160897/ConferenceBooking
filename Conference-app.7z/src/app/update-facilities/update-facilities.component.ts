import { Component, OnInit } from '@angular/core';
import {FacilitiesService} from '../facilities.service';
import { Facility } from '../Model/facility';


@Component({
  selector: 'app-update-facilities',
  templateUrl: './update-facilities.component.html',
  styleUrls: ['./update-facilities.component.css']
})
export class UpdateFacilitiesComponent implements OnInit {

  facility:Facility;
  constructor(public facilities:FacilitiesService) { }

   update_faci(facility){
   this.facilities.updateFaci(facility)
 }

  ngOnInit() {
  }

}
