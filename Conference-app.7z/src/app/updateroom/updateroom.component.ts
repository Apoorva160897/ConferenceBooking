

import { Component, OnInit } from '@angular/core';
import { RoomServiceService } from '../room-service.service';
import { Rooms } from '../Model/Rooms';

@Component({
  selector: 'app-updateroom',
  templateUrl: './updateroom.component.html',
  styleUrls: ['./updateroom.component.css']
})
export class UpdateroomComponent implements OnInit {
  room:Rooms;
  constructor(public rooms:RoomServiceService) {}

    update_rooms(Rooms){
      this.rooms.updateroom(Rooms)
      console.log('updated');
   
   }

  ngOnInit() {
  }

}
