import { Injectable } from '@angular/core';
import { Emp } from './Model/Emp';
//import { HttpClient } from 'selenium-webdriver/http';
import {HttpClient} from '@angular/common/http';
import { Observable, Subscription } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  edata:Emp;
  status:Boolean;
  statusType:Observable<Boolean>;
  
  constructor(public http:HttpClient) { }


  getEmpType(id:number)
  {
    this.edata=new Emp();
    this.edata.EmpId=id;
    return this.http.get("http://localhost:49567/api/Employee/getb?id="+this.edata.EmpId);

  }
  
  getBoolean():Observable<Boolean>{
this.http.get<Boolean>("http://localhost:49567/api/Employee/getc?id="+this.edata.EmpId+"&password="  +this.edata.Password)
    .subscribe((res)=>{
      this.status = res;
     console.log(this.status);
      //return this.status;  
          
      if(this.status){
        window.location.assign("/home");
      }else{
        alert("check your credentials");
      }


    });
   
 return this.statusType;
  }

  checkUser(id:number,pwd:string):Boolean
  {
    this.edata=new Emp();
    this.edata.EmpId=id;
    this.edata.Password=pwd;
     console.log(this.edata.EmpId);
   console.log(this.edata.Password);
   
    
    this.statusType=this.getBoolean();
  //  this.status=this.http.get<Boolean>("http://localhost:49567/api/Employee/getc?id="+this.edata.EmpId+"&password="  +this.edata.Password)
  //   .subscribe(res=>{
  //     this.status = res;
  //     //  console.log(res,"X Value");// this print true "X Value"
  //     //  console.log(this.status);// this prints "true"
  //   });
//console.log('STATUS=' +   this.status);
  console.log(this.statusType);
  console.log(this.status);
   return this.status;
    
  }
}
