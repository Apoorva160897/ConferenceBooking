import { Injectable } from '@angular/core';
import {HttpClient} from'@angular/common/http';
import {Emp} from './Model/Emp';

@Injectable({
  providedIn: 'root'
})
export class EmpServiceService {
emps
edata:Emp;
emplist:string;

  constructor(public http:HttpClient) { }

  addEmps(empdata:Emp)
  {
    console.log(empdata.EmpId);
    console.log(empdata.EmpFName);
    console.log(empdata.EmpLName);
    console.log(empdata.EmpLocation);
    console.log(empdata.EmpType);
    console.log(empdata.Email);
    console.log(empdata.Password);
    console.log(empdata.Notification);
    this.edata=new Emp();
    this.edata.EmpId=empdata.EmpId;
    this.edata.EmpFName=empdata.EmpFName;
    this.edata.EmpLName=empdata.EmpLName;
    this.edata.EmpLocation=empdata.EmpLocation;
    this.edata.EmpType=empdata.EmpType;   
    this.edata.Email=empdata.Email;
    this.edata.Password=empdata.Password;
    this.edata.Notification=empdata.Notification;

    this.http.post('http://localhost:49567/api/Employee/',this.edata)
    .subscribe(res => {
      this.emps=res
    })
    console.log("going to server");
  }

  updateEmps(empdata:Emp)
  {
    console.log(empdata.EmpId);
    console.log(empdata.EmpFName);
    console.log(empdata.EmpLName);
    console.log(empdata.EmpLocation);
    console.log(empdata.EmpType);
    console.log(empdata.Email);
    console.log(empdata.Password);
    console.log(empdata.Notification);
    this.edata=new Emp();
    this.edata.EmpId=empdata.EmpId;
    this.edata.EmpFName=empdata.EmpFName;
    this.edata.EmpLName=empdata.EmpLName;
    this.edata.EmpLocation=empdata.EmpLocation;
    this.edata.EmpType=empdata.EmpType;   
    this.edata.Email=empdata.Email;
    this.edata.Password=empdata.Password;
    this.edata.Notification=empdata.Notification;

    this.http.put('http://localhost:49567/api/Employee/'+this.edata.EmpId,this.edata)
    .subscribe(res => {
      this.emps=res
    })
    console.log("going to server");
  }

}
