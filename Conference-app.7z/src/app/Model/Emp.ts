export class Emp
{
    EmpId:number;
    EmpFName:string;
    EmpLName:string;
    EmpLocation:string;
    EmpType:string;
    Email:string;
    Password:string;
    Notification:string;
    myvalue:boolean;
}
