export class Facility
{
    FacilityType :string;
    TableType :string;
    NoOfMachines :number;
    WhiteBoard:boolean;
    Network:boolean;
    FlipChart:boolean;
    InternetConnectivity:boolean;
    Projector:boolean;
    Screen:boolean;
    Video:boolean;
    Phone:boolean;
}
