import { Time } from '@angular/common';

export class Booking
{
    EmpId:number;
    RoomId:number;
    BookingDate:Date;
    BookingStartTime:Time;
    BookingEndTime:Time;
    ProgramStartDate:Date;
    ProgramEndDate:Date;
    BookingStatus:string;
}