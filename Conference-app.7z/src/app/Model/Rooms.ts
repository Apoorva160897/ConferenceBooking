export class Rooms
{
  RoomId:number;
  FacilityType:string;
  LocCoordinatorId:number;
  RoomName:string;
  RoomType:string;
  Capacity:number;
  Location:string;
}