import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertroomComponent } from './insertroom.component';

describe('InsertroomComponent', () => {
  let component: InsertroomComponent;
  let fixture: ComponentFixture<InsertroomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsertroomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsertroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
