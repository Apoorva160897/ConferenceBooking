import { Component, OnInit } from '@angular/core';
import { RoomServiceService } from '../room-service.service';
import { Rooms } from '../Model/Rooms';

@Component({
  selector: 'app-insertroom',
  templateUrl: './insertroom.component.html',
  styleUrls: ['./insertroom.component.css']
})
export class InsertroomComponent implements OnInit {
  room:Rooms;
  constructor(public rooms:RoomServiceService) { }

  insert_rooms(rooms){
  this.rooms.addrooms(rooms);
}



  ngOnInit() {
  }

}

