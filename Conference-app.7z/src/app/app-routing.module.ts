import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './login/login.component';
import {EmployeeCmpComponent} from './employee-cmp/employee-cmp.component';
import {HomeComponent} from './home/home.component';
import { BookingComponent } from './booking/booking.component';
import {InsertroomComponent} from './insertroom/insertroom.component';
import {UpdateroomComponent} from './updateroom/updateroom.component';
import {InsertFacilitiesComponent} from './insert-facilities/insert-facilities.component'
import {UpdateFacilitiesComponent} from './update-facilities/update-facilities.component'
import {ShowFacilitiesComponent} from './show-facilities/show-facilities.component'
import {BookStatComponent} from './book-stat/book-stat.component'

const routes: Routes = [
  { path:'',redirectTo:'login',pathMatch:'full'},
  { path:'login',component: LoginComponent},
  { path:'employee-cmp',component:EmployeeCmpComponent },
  {path:'home',component:HomeComponent},
  {path:'booking',component:BookingComponent},
  {path:'insertroom',component:InsertroomComponent},
   {path:'updateroom',component:UpdateroomComponent},
   {path:'insert-facilities',component:InsertFacilitiesComponent},
   {path:'update-facilities',component:UpdateFacilitiesComponent},
   {path:'show-facilities',component:ShowFacilitiesComponent},
   {path:'book-stat',component:BookStatComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
