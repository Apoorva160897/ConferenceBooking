import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes-demo',
  templateUrl: './pipes-demo.component.html',
  styleUrls: ['./pipes-demo.component.css']
})
export class PipesDemoComponent implements OnInit {
  firstname:string;
  lastname:string;
  num1:number=12.638467846;
  num2:number=0.5;
  cur1:number=0.25;
  today=new Date();
  str:string="hello world";

  constructor()
   { 
     this.firstname="APOORVA";
     this.lastname="hegde";
    
   }

  ngOnInit() {
  }

}
