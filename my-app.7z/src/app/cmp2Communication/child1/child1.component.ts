import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css']
})
export class Child1Component implements OnInit {

  @Input() title:string;

  //creating a custom event
  @Output() notify:EventEmitter<string>=new EventEmitter<string>();

  fireCustomEvent()
  {
    //firing/triggering custom event called notify
    this.notify.emit(Date());

  }

  constructor() { }

  ngOnInit() {
  }

}
