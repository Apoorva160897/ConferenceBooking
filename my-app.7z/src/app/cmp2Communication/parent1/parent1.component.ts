import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent1',
  templateUrl: './parent1.component.html',
  styleUrls: ['./parent1.component.css']
})
export class Parent1Component implements OnInit {

  constructor() { }

  res:number;
  valuefromChild:string;

  generateRandom()
  {
    this.res=Math.random();

  }

  onListen(msg:string):void
  {
    this.valuefromChild=msg;

  }

  ngOnInit() {
  }

}
