import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-styledemo',
  templateUrl: './styledemo.component.html',
  styleUrls: ['./styledemo.component.css']
})
export class StyledemoComponent implements OnInit {
 constructor() { }

  people:any[]=[
    {
      "name":"apoorva",
      "country":"in"
    },
    {
      "name":"soumya",
      "country":"UK"
    },
    {
      "name":"hegde",
      "country":"US"
    },
    {
      "name":"ABC",
      "country":"UK"
    },
    {
      "name":"XYZ",
      "country":"in"
    }
  ];

  getColor(country)
  {
    switch(country)
    {
      case 'in':return 'green';
      case 'US':return 'blue';
      case 'UK':return 'red';

    }
  }
ngOnInit() {
  }
}
