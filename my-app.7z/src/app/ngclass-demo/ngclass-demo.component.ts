import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngclass-demo',
  templateUrl: './ngclass-demo.component.html',
  styleUrls: ['./ngclass-demo.component.css']
})
export class NgclassDemoComponent implements OnInit {

  constructor() { }
 
  people:any[]=[
    {
      "name":"apoorva",
      "age":"20",
      "country":"in"
    },
    {
      "name":"soumya",
      "age":"29",
      "country":"UK"
    },
    {
      "name":"hegde",
      "age":"20",
      "country":"US"
    },
    {
      "name":"ABC",
      "age":"28",
      "country":"UK"
    },
    {
      "name":"XYZ",
      "age":"25",
      "country":"in"
    }
  ];


  ngOnInit() {
  }

}
