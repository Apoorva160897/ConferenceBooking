import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FirstComponent } from './first.component';
import { SecondComponent } from './second.component';
import { RandomComponent } from './random/random.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { BindingDemoComponent } from './binding-demo/binding-demo.component';
import {FormsModule} from '@angular/forms';
import { Parent1Component } from './cmp2Communication/parent1/parent1.component';
import { Child1Component } from './cmp2Communication/child1/child1.component';
import { PipesDemoComponent } from './pipes-demo/pipes-demo.component';
import { CapitalizePipe } from './capitalize.pipe';
import { ReversePipe } from './reverse.pipe';
import { StyledemoComponent } from './styledemo/styledemo.component';
import { NgclassDemoComponent } from './ngclass-demo/ngclass-demo.component';
import { MakeItBoldDirective } from './make-it-bold.directive';
import { LifeCycleParentComponent } from './lifeCycleDemo/life-cycle-parent/life-cycle-parent.component';
import { LifeCycleChildComponent } from './lifeCycleDemo/life-cycle-child/life-cycle-child.component';

@NgModule({
  declarations: [
    AppComponent,FirstComponent,SecondComponent, RandomComponent, 
    ParentComponent, ChildComponent, BindingDemoComponent,
    Parent1Component, Child1Component, PipesDemoComponent, CapitalizePipe, 
    ReversePipe, StyledemoComponent, NgclassDemoComponent, MakeItBoldDirective, 
    LifeCycleParentComponent, LifeCycleChildComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
