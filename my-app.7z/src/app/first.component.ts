import {Component} from '@angular/core';

//Decorator
@Component({
selector:'First-cmp', 
template:`<h1>firstname is {{fname}} 

and lastname is {{lname}}</h1>

<div>sum of 2 no.s is {{2+3}} </div>`
})
export class FirstComponent
{
    fname:string;
    lname:string;
    
    constructor()
    {
        this.fname="apoorva";
        this.lname="hegde";
    }
}