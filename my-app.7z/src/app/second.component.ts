import {Component} from '@angular/core';

@Component({
    selector:'second-cmp',
    template:`<h1>name is {{fname}} 
    {{mname}} {{lname}}</h1>`

})



export class SecondComponent
{
    fname:string;
    mname:string;
    lname:string;

    constructor()
    {
        this.fname="apoorva".toLowerCase();
        this.mname="i".toUpperCase();
        this.lname="hegde";
    }
}

