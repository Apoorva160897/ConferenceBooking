import { Directive ,ElementRef,Renderer,HostListener} from '@angular/core';


@Directive({
  selector: 'h1,h2[appMakeItBold]'
})
export class MakeItBoldDirective {

  constructor(private el:ElementRef,private renderer:Renderer) { }

  private MakeItBold(inputValue:boolean)
  {
    if(inputValue)
    this.renderer.setElementStyle(this.el.nativeElement,'font-weight','bold');
    else
    this.renderer.setElementStyle(this.el.nativeElement,'font-weight','normal');

  }
 

  @HostListener('mouseenter') onMouseEnter()
  {
    this.MakeItBold(true);
    this.el.nativeElement.style.backgroundColor="red";
  }
  
  @HostListener('mouseleave') onMouseLeave()
  {
    this.MakeItBold(false);
    this.el.nativeElement.style.backgroundColor=null;
  }

}
