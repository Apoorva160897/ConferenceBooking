import { Component, OnInit,VERSION } from '@angular/core';

@Component({
  selector: 'app-binding-demo',
  templateUrl: './binding-demo.component.html',
  styleUrls: ['./binding-demo.component.css']
})
export class BindingDemoComponent implements OnInit {

  str:string;

  constructor() {
    this.str=VERSION.full;
    
   }

   getCurrentDate()
   {
     alert(Date());
   }

  ngOnInit() {
  }

}
