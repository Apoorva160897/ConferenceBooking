import { MakeItBoldDirective } from './make-it-bold.directive';

describe('MakeItBoldDirective', () => {
  it('should create an instance', () => {
    const directive = new MakeItBoldDirective();
    expect(directive).toBeTruthy();
  });
});
