import { Component, OnInit,OnDestroy } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-component-three',
  templateUrl: './component-three.component.html',
  styleUrls: ['./component-three.component.css']
})
export class ComponentThreeComponent implements OnInit,OnDestroy{

  sub:Subscription;
  result:number;

  constructor(private ar:ActivatedRoute) { }

  ngOnInit()
  {
    this.sub=this.ar.params.subscribe(parameter=>{
      this.result=parameter['id'];
    });

  }
  ngOnDestroy()
  {
    this.sub.unsubscribe();

  }

}
