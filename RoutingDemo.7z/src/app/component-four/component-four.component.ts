import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component-four',
  templateUrl: './component-four.component.html',
  styleUrls: ['./component-four.component.css']
})
export class ComponentFourComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
