import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ComponentOneComponent} from './component-one/component-one.component';
import {ComponentTwoComponent} from './component-two/component-two.component';
import {ComponentThreeComponent} from './component-three/component-three.component';
import {Child1Component} from './child1/child1.component';
import {Child2Component} from './child2/child2.component';
import {ComponentFourComponent} from './component-four/component-four.component';


const routes: Routes = [
  { path:'',redirectTo:'component-one',pathMatch:'full'},
  { path:'component-one',component: ComponentOneComponent},
  { path:'component-two',component: ComponentTwoComponent,
    children:
    [
      { path:'',redirectTo:'child-one',pathMatch:'full'},
      { path:'child-one',component: Child1Component},
      { path:'child-two',component: Child2Component}

    ]
},
  { path:'component-three/:id',component: ComponentThreeComponent},
  { path:'component-four',component: ComponentFourComponent, outlet:'sidebar'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
