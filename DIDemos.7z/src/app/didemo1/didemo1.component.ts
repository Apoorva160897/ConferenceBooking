import { Component, OnInit } from '@angular/core';
import {CarService} from './../ServiceClasses/car.service';
import {PistonService} from './../ServiceClasses/piston.service';
import {EngineService} from './../ServiceClasses/engine.service';
import {FuelType} from './../ServiceClasses/FuelType';

@Component({
  selector: 'app-didemo1',
  templateUrl: './didemo1.component.html',
  styleUrls: ['./didemo1.component.css'],
  providers:[CarService,EngineService,PistonService,FuelType]
})
export class DIDemo1Component implements OnInit {
  result:string;

  constructor(car:CarService)
   { 
    console.log("Constructor of component called..");
    this.result=car.runsOn;
   }

  ngOnInit() {
  }

}
