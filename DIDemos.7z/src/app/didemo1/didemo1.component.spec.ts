import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DIDemo1Component } from './didemo1.component';

describe('DIDemo1Component', () => {
  let component: DIDemo1Component;
  let fixture: ComponentFixture<DIDemo1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DIDemo1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DIDemo1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
