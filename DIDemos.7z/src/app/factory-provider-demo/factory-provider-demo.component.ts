import { Component, OnInit } from '@angular/core';
import {Burger,DoubleBurger,CheeseBurger} from './../ServiceClasses/Burger.service';
import {BurgerType} from './../../environments/environment';

const result=BurgerType.typeofBurger;//this is from environment.ts file

//define a function 
export let BurgerFactory=
{
 provide:Burger,//run-time polymorphism..the constructor is checked and conditions are applied
 useFactory:()=>{
   if (result)
   {
     return new DoubleBurger();
   }
   else
   {
    return new CheeseBurger();
   }
 }

}
@Component({
  selector: 'app-factory-provider-demo',
  templateUrl: './factory-provider-demo.component.html',
  styleUrls: ['./factory-provider-demo.component.css'],
  providers:[Burger,DoubleBurger,CheeseBurger,BurgerFactory]
  //note that BurgeFactory is added to provider list                                                                       
})

export class FactoryProviderDemoComponent implements OnInit {
  str:string;

  constructor(h:Burger) 
  {
      this.str= "you are eating:"+ h.type;
  }

  ngOnInit() {
  }

}
