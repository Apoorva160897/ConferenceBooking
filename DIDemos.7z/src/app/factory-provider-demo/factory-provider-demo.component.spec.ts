import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FactoryProviderDemoComponent } from './factory-provider-demo.component';

describe('FactoryProviderDemoComponent', () => {
  let component: FactoryProviderDemoComponent;
  let fixture: ComponentFixture<FactoryProviderDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FactoryProviderDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FactoryProviderDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
