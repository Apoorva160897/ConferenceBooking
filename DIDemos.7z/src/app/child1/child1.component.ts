import { Component, OnInit } from '@angular/core';
import {RandomNumberService} from './../ServiceClasses/random-number.service';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css'],
  //providers:[RandomNumberService]
})
export class Child1Component implements OnInit {
  random1:number;

  constructor(ran:RandomNumberService) 
  { 
    console.log("constructor of child1");
    this.random1=ran.num;
  }

  ngOnInit() {
  }

}
