import { Injectable } from '@angular/core';

@Injectable()

export class Burger
{
    type:string;
    constructor()
    {
        this.type="burger";

    }

}

@Injectable()
export class DoubleBurger extends Burger
{
    type:string;
    constructor()
    {
    super();
    this.type="double burger";
    }
}


@Injectable()
export class CheeseBurger extends DoubleBurger
{
    type:string;
    constructor()
    {
    super();
    this.type="cheese burger";
    }
}