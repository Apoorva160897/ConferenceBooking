import { TestBed } from '@angular/core/testing';

import { PistonService } from './piston.service';

describe('PistonService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PistonService = TestBed.get(PistonService);
    expect(service).toBeTruthy();
  });
});
