import { Injectable } from '@angular/core';

@Injectable()
export class RandomNumberService
 {
num:number;
  constructor() 
  { 
    console.log("constructor of random number called");
    this.num=Math.random();
  }
}
