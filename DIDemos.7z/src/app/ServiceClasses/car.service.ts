import { Injectable } from '@angular/core';
import {EngineService} from './engine.service';

@Injectable(
)
export class CarService {

  runsOn:string;

  constructor(es:EngineService) 
  {
    console.log('object of car  created');
    this.runsOn=es.engineType;
   }
}
