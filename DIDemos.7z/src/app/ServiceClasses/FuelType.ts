import { Injectable } from '@angular/core';

@Injectable()//this makes class as service class
export class FuelType
{
    fuel:string;
    constructor()
    {
        console.log('object of fueltype class created');
        this.fuel='diesel';
    }
}