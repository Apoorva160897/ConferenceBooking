import { Injectable } from '@angular/core';
import {PistonService} from './piston.service';

@Injectable()
export class EngineService {

  engineType:string;
  constructor(ps:PistonService) 
  { 
    console.log('object of engine class created');
    this.engineType='1000cc'+'uses'+ps.pistonType;

  }
}
