import { Injectable } from '@angular/core';
import {FuelType} from './FuelType';

@Injectable()
export class PistonService {

  pistonType:string;
//constructor-based injection
  constructor(ft:FuelType) //object of fuel type is created to build dependency
  {

    console.log('object of piston class created');
    this.pistonType='hydraulic'+'runs on'+ft.fuel;
    
   }
}
