import { Component, OnInit } from '@angular/core';
import {RandomNumberService} from './../ServiceClasses/random-number.service';

@Component({
  selector: 'app-child2',
  templateUrl: './child2.component.html',
  styleUrls: ['./child2.component.css'],
  providers:[RandomNumberService]
})
export class Child2Component implements OnInit {
  random2:number;

  constructor(ran:RandomNumberService)
   {
    console.log("constructor of child2");
    this.random2=ran.num;

   }

  ngOnInit() {
  }

}
